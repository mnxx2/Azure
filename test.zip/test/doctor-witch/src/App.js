import './App.css';
import DoctorWitch from './components/DoctorWitch';

function App() {
  return (
    <div className="App">
      <DoctorWitch/>
    </div>
  );
}

export default App;
