import './Footer.css';

export default function Footer() {
    return(
        <div className="footer">
            <p>&copy; 2025 Doctor Witch 정민아</p>
        </div>
    )
}