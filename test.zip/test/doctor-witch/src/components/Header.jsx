import './Header.css';

export default function Header() {
    return (
        <div className="header">
            <img src="doctor-witch-logo3.png"/>
            <h1>𝘿𝙤𝙘𝙩𝙤𝙧 𝙒𝙞𝙩𝙘𝙝</h1>
        </div>
    )
}